# JS Studio Logo 3D PRO
Primeira versao Android: editor de textos, esferas com sombreamento, fotos, arrastar elementos, salvar projeto local (sem fotos) e exportar PNG.
Nao inclui renderizacao 3D real ou exportacao MP4 ainda.
Para compilar: GitHub Actions > Build Android APK > Run workflow. APK em Artifacts.
